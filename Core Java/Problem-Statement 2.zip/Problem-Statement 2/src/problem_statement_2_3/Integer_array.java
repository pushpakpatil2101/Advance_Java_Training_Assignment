package problem_statement_2_3;
/*2.3 Write a program that allows you  to  create an integer array of  18  elements with
 *     the following values:int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0}. 
 *     Perform the following computations, 
 * a. Compute the sum of elements from index 0 to 14 and stores it at element 15
 * b. Compute the average of all numbers and stores it at element 16 
 * c. Identifies the smallest value from the array and stores it at element 17
 */
public class Integer_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
        int avg=0;
		int arr[] = { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int small=arr[0];
		for(int i=0;i<arr.length-3;i++)
		{
			sum=sum+arr[i];
			avg=sum/2;
			if(small>arr[i])
			{
				small=arr[i];
			}
		}
		arr[15]=sum;
		arr[16]=avg;
		arr[17]=small;
		
		for(int array:arr) {
			System.out.print(" "+array);
		}
	}
}
