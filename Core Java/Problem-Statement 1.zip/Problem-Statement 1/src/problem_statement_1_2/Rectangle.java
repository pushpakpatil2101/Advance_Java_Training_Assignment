package problem_statement_1_2;

import java.util.Scanner;

/* 1.2 Define a class Rectangle with its length and breadth.Follow the below steps,
* 	a.	Provide appropriate constructor(s),which gives facility of constructing Rectangle 
*  		object with default values of length and breadth as 0 or passing value of length 
*  		and breadth externally to constructor.
* 	b.	Provide appropriate accessor & mutator methods to Rectangle class.
* 	c.	Provide methods to calculate area & to display all information of Rectangle.
* 	d.	Design different classTestRectangle class in a separate source file, 
*   	which will contain main method.  From   this  main   method,  create  5  Rectangle  
*   	objects  by   taking  all   necessary information from the user and 
*   	calculate respective area of rectangle objects and display it
*/
class Rectangle1 {
	int length; 
    int width; 
    int area; 
    int perimeter;

    void input() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = scan.nextInt();
        System.out.print("Enter width of rectangle: ");
        width = scan.nextInt();
        scan.close();
    }

    void calculate() {
        area = length * width;
        perimeter = 2 * (length + width);
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Perimeter of Rectangle = " + perimeter);
    }
}
public class Rectangle{
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle1 obj = new Rectangle1();
        obj.input();
        obj.calculate();
        obj.display();
	}
}

