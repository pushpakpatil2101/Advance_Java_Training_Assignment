package problem_statement_6_1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
//6.1 Write a program to add list of student names to ArrayList 
//    and it should find a particular name whether it exists or not in the list.
public class ArrayList_Students {

	@SuppressWarnings({ "resource", "unused" })
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a1=new ArrayList<String>();
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of students :");
		n=scan.nextInt();
		
		System.out.println("Enter the student names :");

		for (int i=0; i<n; i++) 
		{
			a1.add(scan.next());
		}
		System.out.println("student list :");
		
		for (String string : a1) 
		{
			System.out.println("Enter the name of serachable student :");
			String st=scan.next();
			int position=Collections.binarySearch(a1,st);
			System.out.println("position of"+st+"is :"+position);
		}
	}

}
