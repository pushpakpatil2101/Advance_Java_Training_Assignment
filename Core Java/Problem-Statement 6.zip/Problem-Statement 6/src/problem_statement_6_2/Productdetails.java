package problem_statement_6_2;
import java.util.Hashtable;
import java.util.Scanner;
/*6.2	Create a Product class with Product Id & Product Name. 
		Write a program to accept information of 10 products and store that in HashSet. 
		Do following operations, 
			a.Search a particular product in the HashSet.
			b.Remove a particular product from the HashSet by using product id.*/
public class Productdetails {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		Hashtable<String, String> pro_d=new Hashtable<String, String>();
		System.out.println("Enter the product id and name :");
		
		for (int i = 0; i<=3; i++) 
		{
			pro_d.put(scan.next(), scan.next());
		}
		System.out.println("the product list is :");
		System.out.println(pro_d);
		
		System.out.println("Enter the removable product id :");
		String id=scan.next();
		pro_d.remove(id);
		System.out.println("item removed :");
		System.out.println("the product list is :");
		System.out.println(pro_d.toString());
		System.out.println("Enter the product id to be serched :");
	}

}
