package problem_statement_5_1;
//5.1 Manipulate the String str = �JAVA is Simple� asgiven below.
public class String_mani {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String txt= "JAVA is Simple";
		
		//UpperCase
		System.out.println(txt.toUpperCase());
		//LowerCase
		System.out.println(txt.toLowerCase()); 
		
		//1st words of letter
		String[] s1=txt.split("\\s");
		for(String w:s1){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		// Change order
		String[] s2=txt.split("\\s");  
		for(String w:s2){  
			System.out.print(w); 
		}System.out.println();
		
		//String Builder reverse
		StringBuilder s3= new StringBuilder("JAVA is Simple");
		
		//Object words21;
		System.out.println("String = " + s3.toString());
		StringBuilder reverseStr = s3.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
		//Total Length
		System.out.println("length of string " + txt.length());
	}

}
