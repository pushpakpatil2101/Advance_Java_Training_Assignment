package problem_statement_5_2;

public class Split {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String txt= (" 23  +  45  - (  343  /  12 )");
		String[] abc=txt.split("\\\s");
		
		for(String split1:abc){  
			System.out.println(split1); 
		}
	}

}
