package problem_statement_9_1;
/* Given a sorted array containing duplicates, efficiently find frequency of 
 * each element in it without traversing the whole array.
 * Example Input:{2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 }
*/
public class Sorting_array {
	 
	static void findFrequency(int[] input, int n)
	{
		for (int i = 0; i < n; i++)
			input[i]--;
		
		for (int i = 0; i < n; i++)
			input[input[i] % n] += n;
	 
		for (int i = 0; i < n; i++) 
		{
			if ((input[i] / n) != 0)
				
		    System.out.println("Element " + (i + 1) + " occurs "+ input[i] / n + " times");
			
		     // Change the element back to original value
	         input[i] = input[i] % n + 1;
	     }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= { 2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
		int n = arr.length;
		findFrequency(arr, n);

	}

}
