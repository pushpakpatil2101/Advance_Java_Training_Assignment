package problem_statement_1_3;

import java.util.Scanner;

/*	1.3 Create a class Book which describes its book_titleand book_price. Follow the below steps,
 * a.Use getter and setter methods to get & set the Books description.
 * b.Implement createBooks and showBooks methods to create n objects of Book in an array.
 * c.Display the books along with its description as follows,
 * 	Book Title				Price
 * Java Programming 	 Rs 350.50
 * 	Let Us C			 Rs 200.00
 * d.Note: createBooks & showBooksshould not be member functions of Book class
 */
public class BookMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter the Book title");
		String booktitle=scan.nextLine();
		
		System.out.println("Enter the Book price");
		float price=scan.nextFloat();
		//scan.nextLine();
		
		Book n=new Book();
		n.setBooktitle(booktitle);
		n.setBookprice(price);
		System.out.println("Book Title			Price");
		System.out.println(n.getBooktitle()+"			"+n.getBookprice());
		scan.close();
	}

}
