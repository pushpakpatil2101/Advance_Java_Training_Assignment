package problem_statement_12_1;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Repeating_Array {
	// This function prints the
    // first repeating element in arr[]
    static String printFirstRepeating(List<Integer> a) 
    {
        for (int i = 0; i < a.size(); i++) 
        {
            if (Collections.frequency(a, a.get(i)) > 1)
            	return String.valueOf(a.get(i));
        }
        return "there is no repetition number";
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Driver code
        Integer[] arr = {1, 2, 3, 10, 2, 4, 5, 7, 8 };
        Integer[] arr1 = {1, 2, 3, 10, 6, 4, 3, 7, 10};
        
        for(int a:arr) {
        	System.out.print(a);
        }
        System.out.println("  First Repeated Element is:"+printFirstRepeating
        		    												(Arrays.asList(arr)));
        
        for(int b:arr1) {
        	System.out.print(b);
        }
        System.out.println("  First Repeated Element is:"+printFirstRepeating
        															(Arrays.asList(arr1)));
	}

}
 