package problem_statement_1_1;

import java.util.Scanner;

/* 1.1 Write a program to list all, even numbers less than or equal to the number n. 
    Take the value of n as input from the user */
public class EvenNumber {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter value n : ");
		int n =scan.nextInt();
		for(int i=1; i<n; i++)
		{
			if(i%2==0)
			System.out.print(i+" ");
		}    
		
		System.out.println();
		scan.close();
	}
	
}
