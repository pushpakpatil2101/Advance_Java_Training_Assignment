package problem_statement_2_1;

import java.util.Scanner;

/*2.1 Write a program that takes a String through Command Line argument 
 *    and display the length of the string. Also display  the string 
 *    into  uppercase and  check whether it is a  palindrome  or not.
 */
public class String_Commands {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str, rev = "";
	      Scanner scan = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      str = scan.nextLine();
	      int length = str.length();
	 
	      for ( int i=length-1; i>=0; i-- )
	      {
	         rev = rev + str.charAt(i);
	      }
	      System.out.println("length of the string= "+str.length());
	      if (str.equals(rev))
	         System.out.println(str.toUpperCase()+" is a palindrome");
	      else
	         System.out.println(str.toUpperCase()+" is not a palindrome");
	      scan.close();
	}

}
