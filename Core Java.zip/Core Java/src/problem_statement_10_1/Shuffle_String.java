package problem_statement_10_1;
/* You are given 3 strings: first, second, and third. Third String is said to be a 
 * shuffle of first and second if it can be formed by interleaving the characters 
 * of first and second String in a way that maintains the left to right ordering of 
 * the characters from each string.
 */
class Shuffle_String{
	static boolean isInterleaved(String A, String B,String C)
	{
		int M = A.length(), N = B.length();
		boolean IL[][] = new boolean[M + 1][N + 1];
		if ((M + N) != C.length())
	     return false;
	 
		for(int i = 0; i <= M; i++)
		{
			for(int j = 0; j <= N; j++)
			{
				if (i == 0 && j == 0)
					IL[i][j] = true;
				else if (i == 0)
	         {
	             if (B.charAt(j - 1) ==
	                 C.charAt(j - 1))
	                 IL[i][j] = IL[i][j - 1];
	          }
	
	         // B is empty
	         else if (j == 0)
	         {
	             if (A.charAt(i - 1) ==
	                 C.charAt(i - 1))
	                 IL[i][j] = IL[i - 1][j];
	         }
	
			         
			         else if (A.charAt(i - 1) ==
			                  C.charAt(i + j - 1) &&
			                  B.charAt(j - 1) !=
			                  C.charAt(i + j - 1))
			             IL[i][j] = IL[i - 1][j];
						
			         else if (A.charAt(i - 1) !=
			                  C.charAt(i + j - 1) &&
			                  B.charAt(j - 1) ==
			                  C.charAt(i + j - 1))
			             IL[i][j] = IL[i][j - 1];
						
			         else if (A.charAt(i - 1) ==
		                  C.charAt(i + j - 1) &&
		                  B.charAt(j - 1) ==
		                  C.charAt(i + j - 1))
		             IL[i][j] = (IL[i - 1][j] || IL[i][j - 1]);
				     }
				 }
				 	return IL[M][N];
				}

		//Function to run test cases
		static void test(String A, String B, String C)
		{
			if (isInterleaved(A, B, C))
				System.out.println("Third String "+ C + " is valid shuffle of First "
						+ A +" and Second string "+ B);
			else
				System.out.println("Third String "+ C + " is NOT valid shuffle of First "
						+ A +" and Second string "+ B);
		}

		//Driver code
	public static void main(String[] args)
		{
			test("abc", "def", "dabecf");
			test("pqr", "lmno", "plmrqon");
	 
		}
	}
