package problem_statement_2_2;

import java.util.Scanner;

/* 2.2 Write a program that accepts two numbers from the Command Line and print them out. 
 * Then use a for loop  to print the next 13 numbers in the sequence where each number 
 * is the sum of  the previous two. 
 * For example:	input> java Problem 1 3
 * 				output> 1 3 4 7 11 18 29 47 76 123 322 521 843 1364
 */
public class Fibonacci {

	public static void main(String[] args) {
		int count = 13,num1,num2;
		
		Scanner scan =new Scanner(System.in);
		System.out.println("Enter First Number");
		num1 =scan.nextInt();
		System.out.println("Enter Second Number");
		num2 =scan.nextInt();

        System.out.print("Fibonacci Series of "+count+" numbers:");

        for (int i = 1; i <= count; ++i)
        {
            System.out.print(num1+" ");

            int sumOfPrevTwo = num1 + num2;
            num1 = num2;
            num2 = sumOfPrevTwo;
        }
        scan.close();
	}

}
